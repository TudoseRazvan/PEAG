import random

def generate_individual(k, population):
    while True:
        permutation = list(range(2, k + 1))
        random.shuffle(permutation)
        permutation.insert(0, 1)  # Adăugăm 1 pe prima poziție
        permutation.append(k)  # Adăugăm k pe ultima poziție

        # Calculăm calitatea permutării
        quality = sum(1 for i in range(1, k) if permutation[i] < i)

        # Verificăm dacă permutarea generată este unică
        if permutation not in [individual for individual, _ in population]:
            return permutation, quality

while True:
    try:
        k = int(input("Introduceți dimensiunea k a permutării (număr întreg pozitiv): "))
        if k > 1:
            break
        else:
            print("Numărul trebuie să fie un număr întreg pozitiv mai mare decât 1.")
    except ValueError:
        print("Introduceți un număr întreg valid pentru dimensiunea k.")

population = []
for _ in range(10):
    individual = generate_individual(k, population)
    population.append(individual)

for i, (individual, quality) in enumerate(population, 1):
    print(f"Individ {i}: {individual}, Calitate: {quality}")

max_quality = max(quality for _, quality in population)

print(f"Calitate maximă: {max_quality}")
